-- format :
--   attrs array of attributes. numeric index is the attribute id.
--   refs array of triples: {target_node_id, reference_type_id, is_forward}
local n = {}

-- n["i=2254"]={
-- attrs={'i=2254',2,{ns=0,name='ServerArray'},'ServerArray','The list of server URIs used by the server.',
--         [14]='i=12',[15]=1,[17]=0,[18]=0,[19]=1000.0,[20]=0},
-- refs={{"i=2253","i=46",0}}}
-- n["i=2255"]={

return n
