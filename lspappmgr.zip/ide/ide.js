// The URL to the trace logger's EventHandler service.
var trUrl = "/rtl/tracelogger.service/"
var docUrl="https://realtimelogic.com/ba/doc/?url=auxlua.html#tracelogger";


//Must match C code
var TR_set =      1
var TR_data =     2
var TR_acquired = 3

var TS_Http11State =       1
var TS_Request =           2
var TS_RequestHeaders =    3
var TS_setResponseHeaders= 4
var TS_setResponseBody =   5
var TS_TraceButtonState =  6
var TS_TraceLevel =        7


window.define = ace.define;


// Convert from array position 1
function Utf8ArrayToStr(array) {
    var out, i, len, c;
    var char2, char3;

    out = "";
    len = array.length;
    i = 1;
    while(i < len) {
        c = array[i++];
        switch(c >> 4)
        { 
        case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7:
            // 0xxxxxxx
            if(c >= 32 || c >= 10)
                out += String.fromCharCode(c);
            break;
        case 12: case 13:
            // 110x xxxx   10xx xxxx
            char2 = array[i++];
            out += String.fromCharCode(((c & 0x1F) << 6) | (char2 & 0x3F));
            break;
        case 14:
            // 1110 xxxx  10xx xxxx  10xx xxxx
            char2 = array[i++];
            char3 = array[i++];
            out += String.fromCharCode(((c & 0x0F) << 12) |
                                       ((char2 & 0x3F) << 6) |
                                       ((char3 & 0x3F) << 0));
            break;
        }
    }
    return out;
};


function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
};


function getParam(sname)
{
    var params = location.search.substr(location.search.indexOf("?")+1);
    var sval = "";
    params = params.split("&");
    for (var i=0; i<params.length; i++)
    {
        temp = params[i].split("=");
        if ( [temp[0]] == sname ) { sval = temp[1]; }
    }
    return decodeURIComponent(sval);
};


$(document).ready( function() {
    var tabs;
    var tabCounter=0;
    var cleanCounter=0;
    var activeEditInfo;
    var editors={};
    var conElem=$("#console");
    var eh;

    ace.require("ace/ext/language_tools");

    var io=getParam("io");
    if(!io) {
        $("body").html("Incorrect usage: missing io parameter");
        return;
    }
    var base=getParam("base");
    if(!base) base=io;

    function conprint(msg, err) {
        if(err) {
            $("#beep")[0].play();
            msg='<span class="error">'+msg+'</span>';
        }
        conElem.append(msg);
        var e=conElem[0];
        e.scrollTop = e.scrollHeight;
    };

    function println(msg, err) {
        conprint(msg+"\n", err);
    };
    println("Clear console by double clicking in the console pane.");

    function manageErr(data) {
        var err = data.match(/--- Lua error[^:]*:\s*([^:]+):([0-9]+):([^\n]+)/i);
        if(err) {
            var lineno=parseInt(err[2]);
            if(lineno) {
                var fn = "/"+err[1];
                println("File "+fn+":"+lineno+": "+err[3], true)
                findGotoFile(fn,lineno);
            }
            return true;
        }
    };

    function startWS() {
        var tdata="";
        var proto = location.protocol === 'https:' ? 'wss://' : 'ws://';
        var ws = new WebSocket(proto+location.host+trUrl);
        ws.binaryType = "arraybuffer";
        ws.onopen = function(ev)
        {
            println("Connected!");
        };
        ws.onmessage = function (ev)
        {
            var d = new Uint8Array(ev.data);
            switch(d[0]) {
            case TR_data:
                var data = Utf8ArrayToStr(d)
                conprint(escapeHtml(data));
                tdata+=data;
                if(manageErr(tdata) || tdata.length > 5000)
                    tdata="";
                break;
            case TR_acquired:
                println("Connection closed by another client.",true);
                break
            }
        };
        ws.onclose = function(ev)
        { 
            enable("#reconnectb");
            println("WebSocket connection closed with code: "+ev.code,true);
        };
    };

    function connect(force) {
        disable("#reconnectb");
        function ajaxRsp(jqXHR) {
            if( jqXHR.getResponseHeader('tracelogger') && 
                (jqXHR.status == 204 || jqXHR.status == 503) )
            {
                if(jqXHR.status == 204 || force) {
                    startWS();
                }
                else {
                    enable("#reconnectb");
                    println("The TraceLogger is serving another client.\n"+
                             "Click the Connect button to force the other client to disconnect!", true);
                }
            }
            else
            {
                println("Service at "+trUrl+" is not a TraceLogger or the TraceLogger service is not running!\n"+
                         "See the <a href='"+docUrl+"'>documentation</a> for details.", true);
            }
        };
        $.ajax({
            url:trUrl,
            success: function(data, textStatus, jqXHR){ ajaxRsp(jqXHR); },
            error: function (jqXHR){ ajaxRsp(jqXHR); }
        });
    };

    function getActiveURL() {
        if(activeEditInfo) {
            var path='/'+activeEditInfo.fn;
            if(base.length > 0) path='/'+base+path;
            return encodeURI(path.replace(/\/{2,}/g,"/"));
        }
    };

    function enable(id) {
        $(id).prop('disabled', false);
    };
    function disable(id) {
        $(id).prop('disabled', true);
    };
    function disableAllButs() {
        disable("#stdbuts > button");
        if(cleanCounter)
            enable("#saveall");
    };
    disableAllButs();

    function savefile(fn, data, cbfunc) {
        $.ajax({
            url: '../fb.lsp?io='+io+"&fn="+encodeURI(fn),
            data: data,
            contentType: false,
            processData: false,
            type: 'PUT',
            success: function(){
                cbfunc(true);
            },
            error: function(xhr){
                println("Cannot save "+fn+"\n"+xhr.responseText,true);
                cbfunc(false);
            }
        });
    };

    function setIframe(url) {
        $("#accordion").accordion("option", "active", 1);
        $("#result").attr("src", url);
    };

    function saveEditorFile(info,cbfunc) {
        if(!info.clean) {
            var data = info.editor.getValue();
            savefile(info.fn, data, function(ok) {
                println("Saving "+info.fn+": "+ (ok ? "OK" : "FAILED!"), ok?false:true);
                if(ok && !info.clean) {
                    info.editor.getSession().getUndoManager().markClean();
                    info.clean = true;
                    disable("#save");
                    if(--cleanCounter == 0)
                        disable("#saveall");
                }
                if(cbfunc)
                    cbfunc(ok);
            });
        }
        else if(cbfunc)
            cbfunc(true);
    };

    function gotofile(info,lineno)
    {
        if(!info) return;
        setTimeout(function() {
            $("#accordion").accordion("option", "active", 0);
            setTimeout(function() {
                if(info != activeEditInfo)
                    tabs.tabs("option", "active", info.id);
                info.editor.gotoLine(lineno,0,true);
            }, 300);
        }, 300);
    }

    function findGotoFile(fn,lineno) {
        if(!lineno) return;
        var info=activeEditInfo;
        if(info && info.fn == fn) {
            gotofile(info,lineno);
            return;
        }
        for(var k in editors) {
            info = editors[k];
            if(info.fn == fn) {
                gotofile(info,lineno);
                return;
            }
        }
        $.getJSON('../fb.lsp',
		  {operation:"get_content",io:io,id:fn},
		  function(d){
                      if(d.type!="folder")
                          gotofile(addFile(d),lineno);
                  });
    };

    function addTab(fn, content) {
        var title = fn.replace(/.*\/|\/..*$/g, '');
        id = "tabs-" + tabCounter;
        var li="<li><a href='#"+id+"'>"+title+
            "</a> <span class='ui-icon ui-icon-close' role='presentation'>Close</span></li>";
        tabs.find(".ui-tabs-nav" ).append( $(li));
        tabs.append("<div id='" + id + "'>" + content + "</div>");
        tabs.tabs("refresh");

        var idno=tabCounter;
        setTimeout(function() {
            $("#tabs a[href='#tabs-" + idno + "']").trigger('click');
        }, 100);
        tabCounter++;
    };

    var layout = $('body').layout({
        north: {
	    spacing_open: 0,
            maxSize: 30
        },
        west:{
	    size: .3
        },
        center:{
            onresize:function(x, ui) {
                $.layout.callbacks.resizePaneAccordions(x,ui);
                $("#accordion").accordion("refresh");
                tabs.tabs("refresh");
            }
        },
        south:{
	    size: 150
        }
    });

    function addFile(d) {
        var info;
        var id=d.fn;
	switch(d.type){
	case 'png':
	case 'jpg':
	case 'jpeg':
	case 'bmp':
	case 'gif':
            addTab(id, "<img src='"+d.content+"'/>");
            disableAllButs();
            activeEditInfo=null;
	    break;
        default:
            for(var k in editors) {
                if(editors[k].fn == id) {
                    info=editors[k];
                    if(d.size!=info.size) {
                        if(info.clean ||
                           confirm(info.fn+"\n\nThis file has been modified outside of the editor.\n"+
                                   "Do you want to reload it?")) {
                            info.editor.getSession().setValue(d.content);
                        }
                    }
                    tabs.tabs("option", "active", info.id);
                    return;
                }
            }
            var ext = id.match(/[0-9a-z]+$/i)[0].toLowerCase();
            var eid = "editor-"+tabCounter;
            var info={id:tabCounter,fn:id,clean:true,size:d.size};
            activeEditInfo=info;
            editors[tabCounter]=info;
            addTab(id, "<div id='"+eid+"'></div>");
            var editor = ace.edit(eid);
            editor.setOptions({
                enableBasicAutocompletion: true,
                enableSnippets: true,
                enableLiveAutocompletion: false
            });
            info.editor=editor;
            editor.setTheme("ace/theme/github");
            var mode;
            switch(ext) {
            case "lua":
            case "config":
            case "preload":
                mode="lua"
                break;

            case "lsp":
                info.canrun=true;
            case "css":
            case "json":
                mode=ext;
                break;

            case "htm":
            case "html":
                info.canrun=true;
            case "shtml":
                mode="html";
                break;

            case "js":
                mode="javascript"

            case "c":
            case "cpp":
                mode="c_cpp"
                break;
            }
            var ses=editor.getSession();
            if(mode)
                ses.setMode('ace/mode/'+mode);
            editor.setShowPrintMargin(false);
            ses.setValue(d.content);
            editor.gotoLine(1);
            ses.getUndoManager().markClean();
            editor.on('input', function() {
                var clean=ses.getUndoManager().isClean();
                if(info.clean != clean) {
                    info.clean = clean;
                    if(clean) {
                        disable("#save");
                        if(--cleanCounter == 0) {
                            disable("#saveall");
                        }
                    }
                    else {
                        enable("#save");
                        if(cleanCounter++ == 0) {
                            enable("#saveall");
                        }
                    }
                }
            });
        }
        return info;
    };

    $("#accordion").accordion({
        animate: {
            duration: 10
        },
	heightStyle: "fill",
        activate: function() {
            tabs.tabs( "refresh" );
            if(activeEditInfo)
                activeEditInfo.editor.focus();
        }
    });
    $("#accordion").accordion("option", "active", 1);

    function onfile(node, id, d) {
        if(d && typeof d.type !== 'undefined' && !d.isfolder) {
            $("#accordion").accordion("option", "active", 0);
	    //$('#data.content').hide();
            addFile(d);
        }
    };
    createfb("../fb.lsp", "#tree",io, onfile, function(emsg) { println(emsg,true); });

    tabs = $( "#tabs" ).tabs({
        heightStyle: "fill",
        activate: function( event, ui ) {
            var info=editors[parseInt(ui.newPanel.selector.match(/\d+$/g)[0])];
            if(info) {
                var x = info.canrun ? enable : disable;
                x("#run");
                x("#open");
                activeEditInfo=info;
                info.editor.focus();
                if(info.clean)
                    disable("#save");
                else
                    enable("#save");
            }
            else {
                disableAllButs();
                activeEditInfo=null;
            }
        }
    });

    function removeTab(self, id) {
        self.closest("li").remove();
        $("#"+id).remove();
        tabs.tabs("refresh");
    };

    tabs.delegate("span.ui-icon-close", "click", function() {
        var self=$(this);
        var id=self.closest("li").attr("aria-controls");
        var idno = parseInt(id.match(/\d+$/)[0]);
        var info=editors[idno];
        if(info) {
            if(!info.clean) {
                if(confirm('Save changes to the following item?\n'+info.fn)) {
                    saveEditorFile(info, function(ok){
                        if(ok) {
                            delete editors[idno];
                            removeTab(self,id);
                        }
                    });
                    return;
                }
                else if( ! info.clean ) {
                    disable("#save");
                    if(--cleanCounter == 0)
                        disable("#saveall");
                }
            }
            delete editors[idno];
        }
        removeTab(self,id);

    });

    $("#open").click(function() {
        saveEditorFile(activeEditInfo, function() {
            var url = getActiveURL();
            if(url)
                window.open(url);
        });
    });

    $("#run").click(function() {
        saveEditorFile(activeEditInfo, function() {
            var url = getActiveURL();
            if(url)
                setIframe(url);
        });
    });

    $("#save").click(function() {
        if(activeEditInfo)
            saveEditorFile(activeEditInfo);
    });

    $("#saveall").click(function() {
        for(var k in editors)
            saveEditorFile(editors[k]);
    });

    $("#helpb").click(function() {
        setIframe("help.html");
    });

    $("#reconnectb").click(function(){connect(true);});

    function restart() {
        $.getJSON('../manageapp.lsp',
		  {action:"restart",name:io},
		  function(resp){
		      if(resp.ok) {
                          setTimeout(function() {
                              println("Application restarted");
                          }, 1000);
                      }
                      else {
                          var err = resp.error.match(/([^:]+):([0-9]+)/i);
                          if(err)
                              findGotoFile("/"+err[1],parseInt(err[2]))
                          println("Restarting application failed: "+resp.error,true);
                      }
		  });
    };

    $("#restartb").click(function() {
        if(cleanCounter && confirm("Save all files before restarting app?")) {
            var restarted=false;
            var x=function() {
                if(cleanCounter == 0 && !restarted) {
                    restarted=true;
                    restart();
                }
            };
            for(var k in editors)
                saveEditorFile(editors[k],x);
        }
        else
            restart();
    });

    $("#console").dblclick(function() {
        conElem.empty();
    });

    //Workaround for weird event bubbling problem
    var ah=false;
    function ha() {
        if(ah) return;
        ah=true;
        $("#accordion").hide();
        setTimeout(sa, 1000);
    };
    function sa() {
        if(!ah) return;
        ah=false;
        $("#accordion").show().accordion("refresh");
        tabs.tabs("refresh");
    };
    $(".ui-layout-resizer-west").mousedown(ha).mouseup(sa);
    $(".ui-layout-resizer-south").mousedown(ha).mouseup(sa);
    
    $(window).bind('keydown', function(event) {
        if (event.ctrlKey || event.metaKey) {
            switch (String.fromCharCode(event.which).toLowerCase()) {
            case 's':
                event.preventDefault();
                if(activeEditInfo)
                    saveEditorFile(activeEditInfo);
                break;
            }
        }
    });

    window.onbeforeunload = confirmExit;
    function confirmExit()
    {
        if(cleanCounter)
            return "WARNING: YOU HAVE UNSAVED FILES!";
    };

    connect();
});
