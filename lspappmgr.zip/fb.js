function createfb(fb, treeid, io, onfile, onerr) {
    $(treeid)
	.jstree({
	    'core' : {
		'data' : {
		    'url' : fb,
		    'data' : function (node) {
			return { io:io,operation:"get_node",id: node.id };
		    },
                    error:function (xhr) {
                        onerr(xhr.responseText);
		    }
		},
		'check_callback' : function(o, n, p, i, m) {
		    if(m && m.dnd && m.pos !== 'i') { return false; }
		    if(o === "move_node" || o === "copy_node") {
			if(this.get_node(n).parent === this.get_node(p).id)
                            return false;
		    }
		    return true;
		},
		'themes' : {
		    'responsive' : false,
		    'variant' : 'small',
		    'stripes' : true
		}
	    },
	    'sort' : function(a, b) {
		return this.get_type(a) === this.get_type(b) ?
                 (this.get_text(a) > this.get_text(b) ? 1 : -1) :
                 (this.get_type(a) >= this.get_type(b) ? 1 : -1);
	    },
	    'contextmenu' : {
		'items' : function(node) {
		    var tmp = $.jstree.defaults.contextmenu.items();
		    delete tmp.create.action;
		    tmp.create.label = "New";
		    tmp.create.submenu = {
			"create_folder" : {
			    "separator_after" : true,
			    "label" : "Folder",
			    "action" : function(data) {
				var inst = $.jstree.reference(data.reference),
				obj = inst.get_node(data.reference);
				inst.create_node(obj,
                                   { type : "default" },
                                   "last",
                                   function(new_node) {
				       setTimeout(
                                           function() {inst.edit(new_node);},0);
				   });
			    }
			},
			"create_file" : {
			    "label" : "File",
			    "action" : function (data) {
				var inst = $.jstree.reference(data.reference),
				obj = inst.get_node(data.reference);
				inst.create_node(obj, { type : "file" }, "last",
                                                 function(new_node) {
				                     setTimeout(function () {
                                                         inst.edit(new_node); },0);
				                 });
			    }
			}
		    };
		    if(this.get_type(node) === "file") {
			delete tmp.create;
		    }
		    return tmp;
		}
	    },
	    'types' : {
		'default' : { 'icon' : 'folder' },
		'file' : { 'valid_children' : [], 'icon' : 'file' }
	    },
	    'unique' : {
		'duplicate' : function (name, counter) {
		    return name + ' ' + counter;
		}
	    },
	    'plugins' : ['state','dnd','sort','types','contextmenu','unique']
	})
	.on('delete_node.jstree', function (e, data) {
	    $.get(fb, { io:io,operation:"delete_node", 'id' : data.node.id })
		.fail(function (xhr) {
		    data.instance.refresh();
                    onerr(xhr.responseText);
		});
	})
	.on('create_node.jstree', function (e, data) {
	    $.get(fb,
                  { io:io,operation:"create_node", 'type' : data.node.type,
                    'id' : data.node.parent, 'text' : data.node.text })
		.done(function (d) {
		    data.instance.set_id(data.node, d.id);
		})
		.fail(function (xhr) {
		    data.instance.refresh();
                    onerr(xhr.responseText);
		});
	})
	.on('rename_node.jstree', function (e, data) {
	    $.get(fb, { io:io,operation:"rename_node", 'id' : data.node.id,
                              'text' : data.text })
		.done(function (d) {
		    data.instance.set_id(data.node, d.id);
		})
		.fail(function (xhr) {
		    data.instance.refresh();
                    onerr(xhr.responseText);
		});
	})
	.on('move_node.jstree', function (e, data) {
	    $.get(fb, { io:io,operation:"move_node", 'id' : data.node.id,
                              'parent' : data.parent })
		.done(function (d) {
		    //data.instance.load_node(data.parent);
		    data.instance.refresh();
		})
		.fail(function (xhr) {
		    data.instance.refresh();
                    onerr(xhr.responseText);
		});
	})
	.on('copy_node.jstree', function(e, data) {
	    $.get(fb, { io:io,operation:"copy_node", 'id' : data.original.id,
                              'parent' : data.parent })
		.done(function (d) {
		    data.instance.refresh();
		})
		.fail(function (xhr) {
		    data.instance.refresh();
                    onerr(xhr.responseText);
		});
	})
	.bind('dblclick.jstree', function(e, data) {
            var node = $(e.target).closest("li");
            var id = node[0].id;
            $.get(fb, {io:io,operation:"get_content",id:id})
                .done(function (d) {
                    onfile(node, id, d);
                })
		.fail(function (xhr) {
                    onerr(xhr.responseText);
		});
	});
}
