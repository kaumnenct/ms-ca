
var hideWaitBut=0;

function showWaitBut(e)
{
   var x = e.pageX-16;
   var y = e.pageY-16;
   $("#waitimg").show().css("left", x+"px").css("top", y+"px");
   $('#wrap').fadeTo("fast", 0.25);
   var obj=this;
   hideWaitBut = function() {
      $("#waitimg").hide();
      $('#wrap').fadeTo("fast", 1);
   };
   return true;
};

$(function(){
   $("body").append('<img src="/rtl/wfm/circle.gif" alt="" style="border-style:none;position:fixed;display:none" id="waitimg"/>');
   $("#waitbut").click(showWaitBut);
    $(window).on("unload",function(){$("#waitimg").hide();});
});



