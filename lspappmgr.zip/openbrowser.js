$(function(){
    var prohibited=false;
    var running=false;
    var tid;

    function setErr(msg) {
        $("#info").show().html(msg);
    };

    function isurl(path) {
        return path.match(/^https?:\/\/.+\/fs\//i) ? true : false;
    };

    function isnet() {
        return $("select option:selected").text() == "net";
    };

    function stop() {
        running = false;
        if(tid) clearTimeout(tid);
        tid=null;
    };

    function sel() {

        var path=$("#path").val();
        if(isnet() && ! isurl(path))
        {
            $("#path").val("http://");
            if(prohibited) return;
            if(!running) {
                running=true;
                $.get("../find-wfs.lsp", function(data) {
                    if(!running) return;
                    if(data == "prohibited")
                        prohibited=true;
                    else if(data == "notfound") {
                        running=false;
                        tid=setTimeout(sel, 100);
                    }
                    else {
                        stop();
                        $("#path").val(data);
                    }
                })
            }
        }
        else
        {
            stop();
            if( ! isnet() && ( path.length == 0 || path.match(/^https?:/i)))
                $("#path").val("/");
        }
    };
    sel();
    $("select").change(sel);

   $("#browsebut").click(function(event) {
       if($("#dialog").length != 0)
           return;
       var io = $("select option:selected").text();
       if(io)
       {
           var path = $("#path").val();
           if(io == "net" && ! isurl(path))
           {
               setErr("<p>Prior to clicking the 'browse' button, enter the URL to your host computer running the <a href='https://realtimelogic.com/ba/doc/?url=wfs/readme.html'target='_blank'>Web File Manager Server</a>. Example: http://192.168.1.100/fs/, where 192.168.1.100 is your host computer's IP address or domain name and /fs/ is the base path to the Web File Server.</p>");
               return;
           }

           if(showWaitBut)
               showWaitBut(event);
           $.get(window.location.href, {io:io,path:path}, function(data) {
               if(hideWaitBut)
                   hideWaitBut();
               if(data == "ok") {
                   $("#main").append('<div id="dialog"><p>X</p><div id="tree" style=""></div></div>');
                   $("#dialog > p").click(function() {
                       $("#dialog").remove();
                   });
                   function onfile(node, id, d) {
                       if(d.type == "folder" || d.fn.match(/\.zip$/i)) {
                           path+=("/"+d.fn);
                           if(d.type == "folder") path+="/";
                           path = path.replace(/\/{2,}/g,"/");
                           if(io == "net") path = path.replace(/:\//i,"://");
                           $("#path").val(path);
                           $("#dialog").remove();
                       }
                   }
                   createfb("../fb.lsp?browse=true", "#tree",btoa(JSON.stringify({io:io,path:path})), onfile, alert);
               }
               else
                   setErr(data);
            });
       }
       else
           alert("Select a File System");
   });
});
