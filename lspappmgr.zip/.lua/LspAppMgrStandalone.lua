
local log=lspappmgr.log

if mako.udb then -- Install authenticator
   local udb=mako.udb()
   local authdir=ba.create.dir()
   authdir:setauth(ba.create.authenticator(udb,{type="digest"}))
   local okOnNotAuth={css=true,js=true,gif=true}
   local function dirfunc(_ENV,relpath)
      if response:initial() and not request:user() then
         if relpath == "appmgr/login" or relpath == "tracelogger.service/" then
            if authdir:service(request, relpath) then return true end -- failed
            if pcall(function() response:sendredirect(ba.b64decode(request:data"u")) end) then
               return
            end
         end
         if not request:user() then
            if lspappmgr.checkBusy(_ENV) then return end
            local ext = relpath:match("^.+%.([^%.]+)$")
            if not okOnNotAuth[ext] then
               function getTitle() return "Authenticate" end
               function emitBody() -- Used by the theme
                  response:include"/rtl/.appmgr/login.lsp"
               end
               lspappmgr.forward(response,"/rtl/theme/.theme.lsp")
               return true
            end
         end
      end
      return false
   end
   lspappmgr.dirs.rtlDir:setfunc(dirfunc)
end

local function deferred()
   -- Fetch Lspappmgr Config (lc) from mako.conf
   local lc = require"loadconf".lspappmgr or {}

   -- Global set by .LspAppmgr.lua
   local cfg=lspappmgr.config
   local cfgio = lc.ioname and ba.openio(lc.ioname) or ba.openio"home"
   local cfgpath = lc.path or "lspappmgr.conf"
   if cfgio then
      log("Configuration file: %s",cfgio:realpath(cfgpath))
   else
      log("Cannot open configuration I/O '%s'",lc.ioname or "home")
   end

   -- Set the lspappmgr.config.save callback
   function cfg.save()
      if not cfgio then return end
      local fp,err = cfgio:open(cfgpath, "w")
      if fp then
         fp:write(ba.json.encode(cfg.apps))
         fp:close()
         return true
      else
         log("Cannot open %s: %s",cfgio:realpath(cfgpath),err)
      end
   end

   -- Load and start apps in config file
   local fp = cfgio:open(cfgpath)
   if fp then
      cfg.apps = ba.json.decode(fp:read"*a")
      if cfg.apps then
         cfg.init=true
         local saved=cfgio
         cfgio=nil
         cfg.startApp()
         cfgio=saved
      else
         log("Config file %s corrupt",cfgio:realpath(cfgpath))
      end
      fp:close()
   end
   if not cfg.apps and not cfg.save() then
      cfgio=nil
   else
      cfg.init=true
   end
end

ba.thread.run(deferred)
