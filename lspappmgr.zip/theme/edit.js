$(function() {
    $("#sidebar ul.sidemenu button").click(function() {
        var b=$(this);
        var url="/rtl/ide/?io="+b.attr("io");
        if(b.attr("root"))
            url += '&base='+encodeURIComponent('/');
        window.open(url);
    });
    

});
